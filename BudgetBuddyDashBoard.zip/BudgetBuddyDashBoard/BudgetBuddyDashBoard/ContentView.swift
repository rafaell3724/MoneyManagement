//
//  ContentView.swift
//  BudgetBuddyDashBoard
//
//  Created by Mallari, Russel on 9/7/23.
//

import SwiftUI
import Charts
import UIKit

struct ContentView: View {
    
    @State private var averageIsShown = false
    //CHART INFORMATION
    var body: some View {
        VStack{
            Chart{
                BarMark(x: .value("Type", "Groceries"),
                        y: .value("Money Spent", 100))
                .opacity(1)
                
                BarMark(x: .value("Type", "Gas"), y: .value ("Money Spent", 100))
                    .opacity(1)
                BarMark(x:
                        .value("Type", "Extertainment"), y: .value ("Money Spent", 35))
                .opacity(1)
                BarMark(x:
                        .value("Type", "Clothes"), y: .value ("Money Spent", 25))
                .opacity(1)
                BarMark(x: .value("Type", "Subscriptions"), y: .value("Money Spent", 100))
                    .opacity(1)
                
                if averageIsShown{
                    RuleMark(y: .value("Average",70))
                        .foregroundStyle(.white)
                        .annotation(position: .bottom, alignment: .bottomLeading){
                            Text("average: 70")
                        }
                }
            }
            .padding()
            .aspectRatio(2, contentMode: .fit)
            Toggle(averageIsShown ? "show average" : "Hide Average", isOn: $averageIsShown.animation())
            .padding()
            Spacer()
        }
    }
}
    
    //add button to the bottom center to add transaction
    class ViewController: UIViewController
    {
        override func viewDidLoad()
        {
            super.viewDidLoad()
            let button = UIButton()
            button.setTitle("+", for: .normal)
            button.backgroundColor = .systemBlue
            view.addSubview(button)
            button.frame = CGRect (x: 100, y: 100, width: 200, height: 50)
            button.layer.cornerRadius = 25
            button.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        }
        @objc func buttonTapped(){
            view.backgroundColor = .systemMint
        }
    }
    
    //need to make a transaction history drop down menu
    //toggle button dark/light mode
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
