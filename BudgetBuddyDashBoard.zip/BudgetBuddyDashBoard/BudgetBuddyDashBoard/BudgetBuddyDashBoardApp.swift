//
//  BudgetBuddyDashBoardApp.swift
//  BudgetBuddyDashBoard
//
//  Created by Mallari, Russel on 9/7/23.
//

import SwiftUI

@main
struct BudgetBuddyDashBoardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
